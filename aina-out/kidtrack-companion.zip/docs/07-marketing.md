# KidTrack Web Companion — Marketing Pack

> AiNa Marketing Cluster · June 2026

---

## Brand Brief

**Product:** KidTrack Web Companion
**Tagline:** *See everything. Own your data. No subscription.*
**Voice:** Calm, capable, parent-first. Not tech-bro, not toyish. The brand speaks like a
thoughtful product engineer who also happens to be a parent.
**Color:** KidTrack Purple (#7660A8) — reassuring, distinct, not babyish.

---

## Positioning

**For:** Tech-comfortable parents (28–42) who backed the KidTrack Kickstarter and want
a desktop-class view of their toddler's data — without logging into someone else's server.

**Against:** SaaS trackers that charge $14.99/month, store your child's location in a
third-party data center, and lock you out of your own data.

**One-liner:** The web companion that turns your KidTrack watch data into real insight —
on your terms, on your hardware.

---

## Key Messages

1. **Zero subscription.** Your data lives in a SQLite file on your own machine. No monthly fee. No cloud account. No cookie policy.

2. **Open and exportable.** Download your GPS trails as GPX, your sleep history as CSV, or everything as structured JSON. Your child's data is yours.

3. **Designed for parents, not engineers.** A clean dashboard showing battery, location, sleep history, and activity — without configuration files or command-line flags.

4. **Developer-ready.** Raw telemetry console. Full JSON export. Local-only server you can inspect and modify. Open source.

---

## Audience Segments

| Segment | Message emphasis | Channel |
|---------|-----------------|---------|
| Primary parent (non-technical) | Zero subscription · clean dashboard · export for pediatrician | Kickstarter backer update |
| Co-parent / caregiver | Works on any device on the home network · no app install | Kickstarter FAQ |
| Maker / developer | Open source · raw telemetry · GPX export · hackable | GitHub README · maker forums |

---

## Copy Bank

**Hero headline:** See where they are. Know they're safe. Own the data.

**Subheadline:** KidTrack Web Companion is a local-only dashboard for the KidTrack toddler watch. No subscription. No cloud. Runs on your home network.

**Feature bullets:**
- Live GPS tracking on an interactive map
- 7-day sleep history with quality scores
- Hourly activity breakdown — steps, active time, rest
- Real-time BLE telemetry console for developers
- Export in CSV, GPX, or JSON — works with Google Earth, Excel, and any tool you already use
- Multi-child support — track Emma and Liam from the same screen

**CTA:** Download the companion · Get the hardware watch on Kickstarter

---

## marketing.html

See `app/marketing.html` — a standalone single-page marketing site that can be served
from the FastAPI app or hosted statically on GitHub Pages / Vercel.
