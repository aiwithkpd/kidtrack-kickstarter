# KidTrack Web Companion — Ideation PRD

> AiNa Ideation Cluster · June 2026

---

## Architecture Overview

The web companion is a **thin server-rendered dashboard** — all data lives in
a local SQLite database, all HTML is rendered by Jinja2 on the FastAPI server,
and HTMX handles the few live-update interactions (telemetry console, battery
polling, live location). No client-side build step, no React, no WebSockets.

```
Browser ──HTMX──► FastAPI (Jinja2) ──sqlite3──► kidtrack.db
                       │
                  static/css/app.css  (design system, no CDN)
                  static/js/htmx.min.js
                  Leaflet.js CDN (map tiles only)
```

---

## Data Model

### `children`
| column | type | notes |
|--------|------|-------|
| id | INTEGER PK | |
| name | TEXT | "Emma" |
| color | TEXT | hex brand color per child |
| avatar | TEXT | emoji |
| age_months | INTEGER | |
| device_id | TEXT | "KT-001A" |
| gps_mode | TEXT | "high_security" / "battery_saver" |
| firmware_version | TEXT | semver |
| battery_pct | INTEGER | 0–100 |
| ble_connected | INTEGER | 0/1 |

### `location_history`
| column | type | notes |
|--------|------|-------|
| id | INTEGER PK AUTOINCREMENT | |
| child_id | INTEGER FK | |
| lat, lng | REAL | WGS84 |
| accuracy_m | REAL | CEP from NMEA |
| battery_pct | INTEGER | at time of fix |
| timestamp | TEXT | ISO8601 |

### `sleep_records`
| column | type | notes |
|--------|------|-------|
| id | INTEGER PK AUTOINCREMENT | |
| child_id | INTEGER FK | |
| start_time, end_time | TEXT | ISO8601 |
| duration_min | INTEGER | |
| quality_score | INTEGER | 0–100 (IMU restlessness index) |
| nap_type | TEXT | "overnight" / "nap_pm" / "nap_am" |

### `activity_records`
| column | type | notes |
|--------|------|-------|
| id | INTEGER PK AUTOINCREMENT | |
| child_id | INTEGER FK | |
| hour | INTEGER | 0–23 |
| date | TEXT | YYYY-MM-DD |
| step_count | INTEGER | toddler-equivalent steps |
| activity_label | TEXT | "active" / "light" / "still" / "sleep" |
| duration_s | INTEGER | seconds in this state |

### `telemetry_log` (ring buffer, last 200 rows per child)
| column | type | notes |
|--------|------|-------|
| id | INTEGER PK AUTOINCREMENT | |
| child_id | INTEGER | |
| timestamp | TEXT | ISO8601 |
| lat, lng | REAL | |
| accel_x/y/z | REAL | m/s² |
| gyro_x/y/z | REAL | dps |
| rssi | INTEGER | dBm |
| battery_pct | INTEGER | |
| activity_state | TEXT | MCU-reported state |

---

## API Design

### Pages (server-rendered HTML)

| Route | Template | Description |
|-------|----------|-------------|
| `GET /` | `pages/dashboard.html` | Overview stats: battery, steps, sleep, BLE status |
| `GET /tracking` | `pages/tracking.html` | Leaflet map + GPS trail + live position |
| `GET /analytics` | `pages/analytics.html` | 7-day sleep + hourly activity charts |
| `GET /devices` | `pages/devices.html` | Child profiles, GPS mode toggle, firmware info |
| `GET /console` | `pages/console.html` | Dev telemetry stream |
| `GET /roadmap` | `pages/roadmap.html` | V1 shipped + v1.1 backlog |

All page routes accept `?child=<id>` to switch the active child context (default: child 1).

### HTMX Partials

| Route | Method | Trigger | Returns |
|-------|--------|---------|---------|
| `/api/location/json/{child_id}` | GET | JS `setInterval` 5s | JSON `{lat, lng, battery_pct, timestamp}` |
| `/api/telemetry/row/{child_id}` | GET | HTMX `every 1s` | `<tr>` row partial for console table |
| `/api/battery/{child_id}` | GET | HTMX `every 30s` | `<span>` battery partial |
| `/api/stats/{child_id}` | GET | HTMX `every 10s` | `<div>` stats partial |

### Data Actions

| Route | Method | Body | Returns |
|-------|--------|------|---------|
| `/api/devices/{child_id}/gps-mode` | POST | form `mode=high_security\|battery_saver` | HTMX fragment toast |
| `/export/{child_id}/csv` | GET | — | `text/csv` download |
| `/export/{child_id}/gpx` | GET | — | `application/gpx+xml` download |
| `/export/{child_id}/json` | GET | — | `application/json` download |
| `/healthz` | GET | — | `200 ok` |

---

## UX Layout

### Dashboard
```
┌─ Sidebar ──────┐ ┌─ Main ──────────────────────────────────────────┐
│  KidTrack      │ │  Overview         [ Emma ▼ ]                     │
│                │ │  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐            │
│  Dashboard ●   │ │  │ 🔋78%│ │ 📡BLE│ │ 👟2,340│ │ 😴8h2m│           │
│  Tracking      │ │  │Battery│ │ Live │ │ Steps │ │ Sleep │           │
│  Analytics     │ │  └──────┘ └──────┘ └──────┘ └──────┘            │
│  Devices       │ │                                                   │
│  Dev Console   │ │  Recent Location         Activity Today           │
│  Roadmap       │ │  ┌──────────────┐        ┌──────────────────┐    │
│                │ │  │ [Mini Map]   │        │ [Activity bars]  │    │
└────────────────┘ │  └──────────────┘        └──────────────────┘    │
                   └─────────────────────────────────────────────────┘
```

### Tracking Page
- Full-width Leaflet map, 480px height
- Color-coded trail polyline (purple for Emma, blue for Liam)
- Animated child marker (emoji avatar)
- Last-known-location timestamp overlay
- Distance-from-home badge

### Analytics Page
- Sleep section: horizontal bar per day (width = duration/10h), colored by quality (green/amber/red)
- Activity section: 24-column grid, each cell colored by activity_label (purple=active, blue=light, gray=still, dark=sleep)
- Stats summary: total sleep this week, avg nap duration, total steps today

### Devices Page
- Card per child: avatar, name, age, device ID, firmware version
- GPS mode toggle button (toggles between high-security / battery-saver)
- Battery gauge (visual bar)
- Last-seen timestamp
- Export section with three buttons: [CSV] [GPX] [JSON]

### Dev Console Page
- Scrollable table with 200-row ring buffer
- Columns: timestamp, lat/lng, accel XYZ, gyro XYZ, RSSI, battery, state
- Color-coded state badge
- HTMX polls every 1s, prepends new row, truncates to 200
- "Clear console" button
- Copy-all to clipboard button

---

## Non-Functional Requirements

- **Performance:** Page load ≤ 500ms on localhost; HTMX partial ≤ 50ms
- **Offline (partial):** All pages work without internet except map tiles (Leaflet CDN)
- **Accessibility:** Semantic HTML, ARIA labels on interactive elements, keyboard-navigable sidebar
- **Security:** No user input is used in SQL queries without parameterization; no `eval()` or `innerHTML` with untrusted content
- **Data integrity:** SQLite WAL mode enabled; DB path configurable via env var
- **Responsiveness:** Desktop-first (sidebar layout); collapses to hamburger on < 860px
