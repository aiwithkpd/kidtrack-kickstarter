# KidTrack Web Companion — Dev Notes

> AiNa Dev Cluster · June 2026

---

## How to Run

```bash
# From aina-out/kidtrack-companion/app/
uvicorn app.main:app --reload --port 8000
```

Visit http://localhost:8000

On first startup, the app creates `kidtrack.db` and seeds it with:
- 2 child profiles (Emma, Liam)
- 36-point GPS trail for each child (Golden Gate Park, ~3h of history)
- 7 days of sleep records (overnight + afternoon nap when applicable)
- Hourly activity records for today

---

## Project Structure

```
app/
├── app/
│   ├── main.py    — FastAPI app: all routes, HTMX partials, export endpoints
│   └── db.py      — SQLite setup, seeder, query helpers
├── templates/
│   ├── base.html                  — KidTrack-branded shell (sidebar, topbar, toasts)
│   ├── pages/
│   │   ├── dashboard.html         — Stats overview, mini activity grid, device status
│   │   ├── tracking.html          — Leaflet.js map with GPS trail + live polling
│   │   ├── analytics.html         — 7-day sleep bars + hourly activity chart
│   │   ├── devices.html           — Device cards, GPS mode toggle, export buttons
│   │   ├── console.html           — Dev telemetry console (HTMX 1Hz stream)
│   │   └── roadmap.html           — v1.0 shipped / v1.1 backlog
│   └── partials/
│       └── telemetry_row.html     — One <tr> for the live telemetry stream
├── static/
│   ├── css/app.css                — Design system (golden starter)
│   └── js/htmx.min.js             — HTMX (vendored)
├── requirements.txt
├── .env.example
└── Dockerfile
```

---

## Architecture Decisions

### No ORMs, no extra deps
The DB layer uses `sqlite3` from Python's standard library. `get_conn()` returns
a `Row`-factory connection so rows behave like dicts. No SQLAlchemy, no Alembic.
The schema is created via `executescript()` with `CREATE TABLE IF NOT EXISTS` — safe
to call on every startup.

### HTMX for live interactivity
Live telemetry uses HTMX's `hx-trigger="every 1s"` on the `<tbody>` — the server
returns one `<tr>` per call, HTMX prepends it with `hx-swap="afterbegin"`, and a
JS `trimRows()` function prunes to 200 rows. No WebSockets, no SSE, no build step.

Battery and connection status use `every 30s` and `every 10s` polling respectively —
low-frequency enough to be invisible to the user.

### GPS trail simulation
The trail is seeded on startup from `db._gen_trail()` — a parametric elliptical
park loop around configurable GPS coordinates. Override `BASE_LAT`/`BASE_LNG` in
`.env` to relocate the demo to your actual park.

The `/api/location/json/{child_id}` endpoint returns the latest DB row; the tracking
page polls it every 5s from JavaScript and moves the Leaflet marker.

### Telemetry simulation
`_sim_telemetry()` in `main.py` generates deterministic-ish values via `math.sin`
seeded by wall-clock time + child_id. No DB write — the console stream is
entirely in-memory. This avoids unbounded DB growth while still producing
realistic-looking data for demos.

### Export
Three formats served as streaming file downloads:
- **CSV** — location history + sleep + activity in one file with section headers
- **GPX** — standard `<trkseg><trkpt>` format with battery in `<extensions>`
- **JSON** — full structured dump (child metadata + all history)

All use `StreamingResponse` or `Response` with the appropriate MIME type and
`Content-Disposition: attachment` header.

---

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `APP_NAME` | `KidTrack` | App title in browser / sidebar |
| `APP_TAGLINE` | `Web Companion Dashboard` | Subtitle |
| `DB_PATH` | `./kidtrack.db` | Path to SQLite file |
| `BASE_LAT` | `37.7694` | Seeded GPS trail center latitude |
| `BASE_LNG` | `-122.4862` | Seeded GPS trail center longitude |

---

## What's Stubbed / Not Real

- **BLE connection** — All telemetry is simulated. Web browsers cannot access BLE
  GATT servers directly on iOS/Android. Real data ingestion requires the native
  mobile app to POST to a `/api/ingest` webhook (planned v1.1).
- **Live battery reads** — Battery % is seeded at startup; the HTMX polling returns
  the same DB value. In v1.1, the mobile app will update this via ingest.
- **GPS mode toggle** — The POST endpoint updates `children.gps_mode` in SQLite
  and returns a badge fragment. No actual BLE write to the watch.
- **OTA firmware** — Not present. Nordic DFU over BLE requires the native app.

---

## Adding Real Data

When the v1.1 mobile ingest webhook is added, it will accept:

```http
POST /api/ingest
Content-Type: application/json

{
  "child_id": 1,
  "lat": 37.7694,
  "lng": -122.4862,
  "accuracy_m": 3.5,
  "battery_pct": 78,
  "accel_x": 0.12, "accel_y": -0.04, "accel_z": 9.83,
  "gyro_x": 1.2, "gyro_y": -0.8, "gyro_z": 0.3,
  "rssi": -68,
  "activity_state": "ACTIVE",
  "timestamp": "2026-06-20T14:32:10"
}
```

This will write to `location_history` and trigger real-time dashboard updates.

---

## Known Limitations

- **No auth** — The dashboard is localhost-only in v1.0. Anyone on the LAN can access it.
- **SQLite single-writer** — Fine for household use. Multi-household / multi-writer needs Postgres.
- **Leaflet tiles require internet** — Map shows blank tiles if offline. Pre-download MBTiles cache is v1.1.
- **Jinja2 `dict.update()` in templates** — Used for building `act_by_hour` lookup in analytics template. This is a Jinja2 quirk; the `update()` method returns `None`, which is why it's wrapped in `{% if %}`.
