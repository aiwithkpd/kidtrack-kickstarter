# KidTrack Web Companion — Ops Runbook

> AiNa Ops Cluster · June 2026

---

## Deployment

### Local (default)

```bash
cd aina-out/kidtrack-companion/app
uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```

Open http://localhost:8000

### LAN access (household)

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

All devices on the home network can now reach `http://<your-ip>:8000`. No auth in v1.0 — restrict to trusted LAN only.

### Raspberry Pi (headless)

```bash
# Auto-start on boot with systemd
sudo nano /etc/systemd/system/kidtrack.service
```

```ini
[Unit]
Description=KidTrack Web Companion
After=network.target

[Service]
User=pi
WorkingDirectory=/home/pi/kidtrack-companion/app
ExecStart=/usr/local/bin/uvicorn app.main:app --host 0.0.0.0 --port 8000
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable kidtrack
sudo systemctl start kidtrack
sudo systemctl status kidtrack
```

### Docker

```bash
cd aina-out/kidtrack-companion/app
docker build -t kidtrack-companion .
docker run -p 8000:8000 -v $(pwd)/data:/app/data kidtrack-companion
```

### Fly.io

```bash
fly launch --name kidtrack-companion
fly deploy
```

---

## Health Check

```bash
curl http://localhost:8000/healthz
# → ok
```

The `/healthz` endpoint returns `200 ok` if the FastAPI process is running.
It does NOT check the DB — add a DB ping if you need deeper health checking.

---

## Database

**Location:** `./kidtrack.db` (SQLite, relative to `app/`)

**Backup:**
```bash
cp kidtrack.db kidtrack.db.bak-$(date +%Y%m%d)
```

**Reset demo data:**
```bash
rm kidtrack.db
# restart the server — it will re-seed automatically
```

**Inspect:**
```bash
sqlite3 kidtrack.db ".tables"
sqlite3 kidtrack.db "SELECT name, battery_pct, gps_mode FROM children"
sqlite3 kidtrack.db "SELECT COUNT(*) FROM location_history"
```

---

## Common Operations

### Change GPS base coordinates (demo trail)

```bash
# In .env or as env vars:
BASE_LAT=51.5074
BASE_LNG=-0.1278  # London
```

Then `rm kidtrack.db` and restart to re-seed with new coordinates.

### Add a child manually

```bash
sqlite3 kidtrack.db "INSERT INTO children VALUES (3,'Sofia','#2E8B57','👧',42,'KT-003C','battery_saver','1.2.1',95,1)"
```

### Clear location history

```bash
sqlite3 kidtrack.db "DELETE FROM location_history WHERE child_id=1"
```

### Check log volume

```bash
# uvicorn logs go to stdout — redirect if needed:
uvicorn app.main:app --port 8000 >> /var/log/kidtrack.log 2>&1 &
wc -l /var/log/kidtrack.log
```

---

## Incident Scenarios

### App won't start — "no module named 'fastapi'"

```bash
# Activate the project venv first:
source .venv/bin/activate
# or point uvicorn at the venv directly:
/path/to/.venv/bin/uvicorn app.main:app --port 8000
```

### `OperationalError: unable to open database file`

The DB path is not writable. Check permissions:
```bash
ls -la kidtrack.db
chmod 664 kidtrack.db
```
Or set `DB_PATH` env var to a writable location.

### Tracking map is blank (no tiles)

Leaflet requires internet access for OpenStreetMap tile CDN. Either:
1. Connect to the internet
2. Pre-download MBTiles (v1.1 feature): `tileserver-gl serve maptiles.mbtiles`

### Telemetry console shows no rows

The console uses HTMX `hx-trigger="every 1s"`. Check:
1. Browser devtools → Network tab — is `/api/telemetry/row/1` being called?
2. Is HTMX loaded? Check `<script src="/static/js/htmx.min.js">` in page source.
3. Does the endpoint return 200? `curl http://localhost:8000/api/telemetry/row/1`

### Export download is empty

Check that `kidtrack.db` has data:
```bash
sqlite3 kidtrack.db "SELECT COUNT(*) FROM location_history"
```
If 0, the DB was reset. Restart the server to re-seed.

---

## Upgrade / Rollback

**Upgrade:**
```bash
git pull
# No migration needed for v1.0 → v1.x schema changes — DB is re-created on first run
# Backup first if you have real data you want to keep
cp kidtrack.db kidtrack.db.pre-upgrade
uvicorn app.main:app --port 8000
```

**Rollback:**
```bash
git revert HEAD
cp kidtrack.db.pre-upgrade kidtrack.db
uvicorn app.main:app --port 8000
```

---

## Scaling Notes

| Scenario | Approach |
|----------|----------|
| 1–5 household users | SQLite, current setup is fine |
| 10+ concurrent users | Consider Postgres + SQLAlchemy async |
| Remote access | Use Tailscale or Cloudflare Tunnel (not raw port-forwarding) |
| High write rate (real BLE ingest) | Add Redis queue between ingest endpoint and SQLite writer |
| Multi-household SaaS | Full redesign: Postgres, auth, multi-tenancy — 6+ engineer-weeks |
