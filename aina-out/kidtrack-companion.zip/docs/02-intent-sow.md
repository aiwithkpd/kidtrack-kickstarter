# KidTrack Web Companion — Intent & Statement of Work

> AiNa Intent Cluster · June 2026

---

## Domain

**Consumer IoT + Parenting Tech** — BLE-connected hardware device companion
software for parents of toddlers in the 1–4 year age band.

### Dynamics
- Parents access the device sporadically (check-ins vs. continuous monitoring); the web dashboard is a review tool, not an alert surface
- Data sensitivity is high (child location) — local-first architecture is both a feature and a compliance stance
- The maker/developer persona is small (~5–10% of users) but loud and influential in open-source hardware communities
- Battery life shapes almost every UX decision — every polling interval has a power cost visible to the user

### Constraints
- COPPA / GDPR: child location data must never leave the household unless explicitly opted in — local SQLite enforces this architecturally
- App Store restrictions don't apply (web app), but BLE Web API is still too immature and inconsistently available to rely on for Phase 1
- The KidTrack Kickstarter timeline means the web companion ships before widespread hardware availability — demo/simulator mode is the primary v1.0 use case

---

## Executive Summary

Parents who back the KidTrack Kickstarter receive a BLE hardware watch and a
mobile companion app. What they lack is a **data review and export surface** —
a web dashboard for historical tracking analysis, sleep reports, and raw data
access that doesn't require holding a phone. The web companion fills this gap
as a locally-hosted FastAPI server: no subscription, no cloud, runs on the
same home network as the mobile app.

---

## In Scope — V1

- Parent dashboard showing live (simulated) stats: battery, BLE status, last location, step count, sleep quality
- GPS tracking page: Leaflet map with historical trail + HTMX-polled location updates
- Sleep analytics: 7-day duration bars + quality score calendar
- Activity analytics: hourly step/activity breakdown
- Multi-child profile management (toggle between children, each with color + avatar)
- GPS mode toggle (high-security / battery-saver) persisted to SQLite
- Developer console: 1Hz HTMX-polled telemetry stream (NMEA, IMU XYZ, RSSI, state)
- Data export in CSV, GPX, and JSON formats (direct browser download)
- Roadmap page showing v1.0 vs. v1.1 backlog
- Local SQLite database with demo seed data

---

## Out of Scope — V1 (Deliberate)

- **Real BLE connection** — Web Bluetooth API is not reliably available on iOS, Android Chrome, or Firefox; native mobile app remains the BLE bridge → v1.1 ingest webhook
- **User authentication** — Household-only local server; adding auth adds complexity without a clear threat model at localhost
- **Cloud hosting with TLS cert management** — Users who want remote access are directed to Tailscale or Cloudflare Tunnel; not our problem to solve in v1.0
- **OTA firmware flash** — Requires Nordic DFU BLE write; WebUSB/WebBLE not reliable enough → stays in native app
- **Push notifications** — No service worker in v1.0; browser tab must be open for any alerts
- **AI/ML sleep quality inference** — Simple IMU threshold model is sufficient; ML deferred until labeled dataset from beta users exists

---

## Variant Design

### Variant 1: Lean (tier_lean)

**Budget band (USD):** $0 (self-hosted)
**Engineer-weeks:** 1–2
**Ops complexity:** low
**Recommended stack:** FastAPI + SQLite + server-side Jinja2, no JS charts
**Target scale:** single household, 1–2 users

**Tradeoffs:**
- Minimal JS (HTMX only) — fast, no build step
- Charts are CSS-bar-only — no animation, less insight
- No real-time map — last-known-location text only
- Easy to deploy on a Raspberry Pi
- No export functionality

**Kill criteria:**
- If the user wants real-time live tracking with sub-second updates
- If more than one household needs to share data

### Variant 2: Recommended (tier_recommended)

**Budget band (USD):** $0–$6/mo infra
**Engineer-weeks:** 2–3
**Ops complexity:** low
**Recommended stack:** FastAPI + SQLite + Jinja2 + HTMX + Leaflet.js + inline SVG charts
**Target scale:** 1–5 household users, 1–4 child profiles

**Tradeoffs:**
+ Full Leaflet map with trail + live-polled marker position
+ HTMX telemetry console streams at 1Hz with no WebSocket complexity
+ SVG/CSS analytics charts (sleep bars, activity heatmap)
+ CSV/GPX/JSON export as file downloads
+ Demo seed data makes the app immediately useful before hardware ships
- Leaflet requires internet connection for OSM tile CDN (offline tiles deferred)
- SQLite caps write concurrency at ~1 writer

**Kill criteria:**
- If multi-tenant (multiple households) — need Postgres + auth
- If sub-second map updates are required — need WebSockets

### Variant 3: Hardened (tier_hardened)

**Budget band (USD):** $15–40/mo
**Engineer-weeks:** 6–8
**Ops complexity:** high
**Recommended stack:** FastAPI + Postgres + Redis pub/sub + WebSockets + offline MBTiles + Tailscale HTTPS
**Target scale:** 10–50 households

**Tradeoffs:**
+ Real-time WebSocket updates (&lt;200ms map latency)
+ Postgres for multi-user, multi-household isolation
+ Offline map tiles bundled (no CDN dependency)
+ Full auth with household invite codes
+ Sentry error tracking + Prometheus metrics
- Significant ops overhead (Postgres, Redis, Tailscale, cert renewal)
- 6–8 engineer-weeks is 3× the recommended variant

**Kill criteria:**
- If the product stays single-household — hardened is overkill

### Recommended variant: tier_recommended

The recommended variant matches the PRD's BLE-first, local-only, no-subscription ethos while delivering a polished, immediately usable web companion.

---

## Open Questions / Risks

- **BLE bridge timing:** When will the mobile app be able to POST telemetry to the web companion's `/api/ingest` endpoint? Until then, all data is simulated.
- **Offline maps:** Will v1.1 users need map tiles without internet? Leaflet + MBTiles via local tile server adds ~2 engineer-weeks.
- **Child data retention policy:** Does the user want location history auto-pruned after N days? No retention policy in v1.0 — DB grows unbounded.
- **Multi-household:** If the Kickstarter succeeds and the web companion becomes a hosted service, the entire auth + multi-tenancy design would need to be revisited.
- **GPX export accuracy:** GPS accuracy from the KidTrack watch (~3.5m CEP from MAX-M8Q) should be disclosed in the GPX `<extensions>` field — currently omitted in v1.0.
