"""KidTrack Web Companion — SQLite setup and demo seeder.

Seeded demo: two children (Emma, Liam), 36-point GPS trail around Golden Gate Park,
7 days of sleep records, hourly activity for today, and an in-memory telemetry ring buffer.

All coordinates are Golden Gate Park, SF — override BASE_LAT / BASE_LNG via env.
"""
from __future__ import annotations

import math
import os
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

DB_PATH = Path(os.environ.get("DB_PATH", str(Path(__file__).resolve().parent.parent / "kidtrack.db")))

BASE_LAT = float(os.environ.get("BASE_LAT", "37.7694"))
BASE_LNG = float(os.environ.get("BASE_LNG", "-122.4862"))

CHILDREN_SEED = [
    {"id": 1, "name": "Emma",  "color": "#7660A8", "avatar": "👧", "age_months": 36, "device_id": "KT-001A", "battery": 78},
    {"id": 2, "name": "Liam",  "color": "#2C6CB0", "avatar": "👦", "age_months": 28, "device_id": "KT-002B", "battery": 92},
]

_ACTIVITY_PATTERN = [
    (6, "still", 0), (7, "light", 120), (8, "active", 450), (9, "active", 680),
    (10, "active", 520), (11, "light", 280), (12, "still", 80), (13, "sleep", 0),
    (14, "sleep", 0), (15, "light", 150), (16, "active", 720), (17, "active", 580),
    (18, "light", 320), (19, "light", 180), (20, "still", 40),
]

_SCHEMA = """
CREATE TABLE IF NOT EXISTS children (
    id              INTEGER PRIMARY KEY,
    name            TEXT NOT NULL,
    color           TEXT,
    avatar          TEXT,
    age_months      INTEGER,
    device_id       TEXT,
    gps_mode        TEXT    DEFAULT 'high_security',
    firmware_version TEXT   DEFAULT '1.2.1',
    battery_pct     INTEGER DEFAULT 85,
    ble_connected   INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS location_history (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    child_id    INTEGER REFERENCES children(id),
    lat         REAL,
    lng         REAL,
    accuracy_m  REAL,
    battery_pct INTEGER,
    timestamp   TEXT
);
CREATE TABLE IF NOT EXISTS sleep_records (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    child_id      INTEGER REFERENCES children(id),
    start_time    TEXT,
    end_time      TEXT,
    duration_min  INTEGER,
    quality_score INTEGER,
    nap_type      TEXT
);
CREATE TABLE IF NOT EXISTS activity_records (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    child_id       INTEGER REFERENCES children(id),
    hour           INTEGER,
    date           TEXT,
    step_count     INTEGER,
    activity_label TEXT,
    duration_s     INTEGER
);
"""


def get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init() -> None:
    conn = get_conn()
    conn.executescript(_SCHEMA)
    if conn.execute("SELECT COUNT(*) FROM children").fetchone()[0] == 0:
        _seed(conn)
    conn.close()


# ── Public query helpers ───────────────────────────────────────────────────────

def get_children(conn: sqlite3.Connection) -> list[sqlite3.Row]:
    return conn.execute("SELECT * FROM children ORDER BY id").fetchall()


def get_child(conn: sqlite3.Connection, child_id: int) -> sqlite3.Row | None:
    return conn.execute("SELECT * FROM children WHERE id=?", (child_id,)).fetchone()


def get_trail(conn: sqlite3.Connection, child_id: int, limit: int = 36) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT lat,lng,accuracy_m,battery_pct,timestamp FROM location_history "
        "WHERE child_id=? ORDER BY timestamp DESC LIMIT ?",
        (child_id, limit)
    ).fetchall()


def get_latest_location(conn: sqlite3.Connection, child_id: int) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT lat,lng,accuracy_m,battery_pct,timestamp FROM location_history "
        "WHERE child_id=? ORDER BY timestamp DESC LIMIT 1",
        (child_id,)
    ).fetchone()


def get_sleep_records(conn: sqlite3.Connection, child_id: int, days: int = 7) -> list[sqlite3.Row]:
    since = (datetime.now() - timedelta(days=days)).isoformat()
    return conn.execute(
        "SELECT * FROM sleep_records WHERE child_id=? AND start_time >= ? ORDER BY start_time DESC",
        (child_id, since)
    ).fetchall()


def get_activity_today(conn: sqlite3.Connection, child_id: int) -> list[sqlite3.Row]:
    today = datetime.now().date().isoformat()
    return conn.execute(
        "SELECT hour,step_count,activity_label FROM activity_records "
        "WHERE child_id=? AND date=? ORDER BY hour",
        (child_id, today)
    ).fetchall()


def set_gps_mode(conn: sqlite3.Connection, child_id: int, mode: str) -> None:
    conn.execute("UPDATE children SET gps_mode=? WHERE id=?", (mode, child_id))
    conn.commit()


# ── Seeder ────────────────────────────────────────────────────────────────────

def _seed(conn: sqlite3.Connection) -> None:
    now = datetime.now()

    for c in CHILDREN_SEED:
        conn.execute(
            "INSERT INTO children VALUES (?,?,?,?,?,?,'high_security','1.2.1',?,1)",
            (c["id"], c["name"], c["color"], c["avatar"], c["age_months"], c["device_id"], c["battery"])
        )

    trail = _gen_trail(BASE_LAT, BASE_LNG, 36, 0.0009)
    for c in CHILDREN_SEED:
        off = (c["id"] - 1) * 0.0004
        for i, (lat, lng) in enumerate(trail):
            ts = (now - timedelta(minutes=(35 - i) * 5)).isoformat(timespec="seconds")
            conn.execute(
                "INSERT INTO location_history (child_id,lat,lng,accuracy_m,battery_pct,timestamp) VALUES (?,?,?,?,?,?)",
                (c["id"], lat + off, lng + off, round(3.2 + i * 0.08, 1), max(20, c["battery"] - i // 3), ts)
            )

    for c in CHILDREN_SEED:
        for day_ago in range(7):
            date = (now - timedelta(days=day_ago)).date()
            s_hour = 21
            s_min  = [15, 30, 0, 45, 20, 50, 10][day_ago]
            s_start = datetime.combine(date - timedelta(days=1), datetime.min.time()).replace(
                hour=s_hour, minute=s_min
            )
            dur  = 510 + (day_ago * 13 % 45)
            qual = 68 + (day_ago * 11 % 27) + (c["id"] * 5)
            conn.execute(
                "INSERT INTO sleep_records (child_id,start_time,end_time,duration_min,quality_score,nap_type) VALUES (?,?,?,?,?,?)",
                (c["id"], s_start.isoformat(), (s_start + timedelta(minutes=dur)).isoformat(), dur, min(qual, 98), "overnight")
            )
            if day_ago % 3 != 0:
                nap_s = datetime.combine(date, datetime.min.time()).replace(hour=13, minute=20)
                nap_d = 70 + (day_ago * 17 % 55)
                conn.execute(
                    "INSERT INTO sleep_records (child_id,start_time,end_time,duration_min,quality_score,nap_type) VALUES (?,?,?,?,?,?)",
                    (c["id"], nap_s.isoformat(), (nap_s + timedelta(minutes=nap_d)).isoformat(),
                     nap_d, 52 + (day_ago * 9 % 32), "nap_pm")
                )

    today = now.date().isoformat()
    for c in CHILDREN_SEED:
        for hour, label, steps in _ACTIVITY_PATTERN:
            conn.execute(
                "INSERT INTO activity_records (child_id,hour,date,step_count,activity_label,duration_s) VALUES (?,?,?,?,?,?)",
                (c["id"], hour, today, steps + (c["id"] - 1) * 35, label, 3600)
            )

    conn.commit()


def _gen_trail(center_lat: float, center_lng: float, n: int, radius: float) -> list[tuple[float, float]]:
    pts = []
    for i in range(n):
        angle = (2 * math.pi * i) / n
        r = radius * (0.75 + 0.45 * abs(math.sin(i * 0.71)))
        pts.append((
            round(center_lat + r * math.cos(angle) * 0.55, 6),
            round(center_lng + r * math.sin(angle), 6),
        ))
    return pts
