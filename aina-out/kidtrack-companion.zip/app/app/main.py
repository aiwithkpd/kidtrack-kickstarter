"""KidTrack Web Companion — FastAPI + HTMX server.

Pages:   /  /tracking  /analytics  /devices  /console  /roadmap
HTMX:    /api/telemetry/row/<id>  /api/battery/<id>  /api/stats/<id>
JSON:    /api/location/json/<id>
Actions: /api/devices/<id>/gps-mode  /export/<id>/<format>
"""
from __future__ import annotations

import csv
import io
import math
import os
import random
import time
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from . import db

APP_NAME    = os.environ.get("APP_NAME", "KidTrack")
APP_TAGLINE = os.environ.get("APP_TAGLINE", "Web Companion Dashboard")

BASE_DIR   = Path(__file__).resolve().parent.parent
app        = FastAPI(title=APP_NAME)
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
templates  = Jinja2Templates(directory=str(BASE_DIR / "templates"))


@app.on_event("startup")
def _startup():
    db.init()


# ── Helpers ────────────────────────────────────────────────────────────────────

_ICONS = {
    "grid":    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/></svg>',
    "map":     '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M9 3 4 5v16l5-2 6 2 5-2V3l-5 2-6-2Z"/><line x1="9" y1="3" x2="9" y2="19"/><line x1="15" y1="5" x2="15" y2="21"/></svg>',
    "chart":   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>',
    "device":  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><rect x="5" y="2" width="14" height="20" rx="2"/><line x1="12" y1="18" x2="12" y2="18.01"/></svg>',
    "console": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/></svg>',
    "roadmap": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M9 3 4 5v16l5-2 6 2 5-2V3l-5 2-6-2Z"/><line x1="9" y1="3" x2="9" y2="19"/><line x1="15" y1="5" x2="15" y2="21"/></svg>',
}

NAV = [
    {"key": "dashboard", "label": "Dashboard",   "href": "/",          "icon": _ICONS["grid"]},
    {"key": "tracking",  "label": "Tracking",    "href": "/tracking",  "icon": _ICONS["map"]},
    {"key": "analytics", "label": "Analytics",   "href": "/analytics", "icon": _ICONS["chart"]},
    {"key": "devices",   "label": "Devices",     "href": "/devices",   "icon": _ICONS["device"]},
    {"key": "console",   "label": "Dev Console", "href": "/console",   "icon": _ICONS["console"]},
    {"key": "roadmap",   "label": "Roadmap",     "href": "/roadmap",   "icon": _ICONS["roadmap"]},
]

ROADMAP_ITEMS = [
    {"title": "Dashboard + SQLite DB",        "state": "done",     "note": "v1.0 shipped"},
    {"title": "Leaflet GPS tracking map",     "state": "done",     "note": "v1.0 shipped"},
    {"title": "Sleep & activity analytics",  "state": "done",     "note": "v1.0 shipped"},
    {"title": "Device management + GPS mode","state": "done",     "note": "v1.0 shipped"},
    {"title": "Dev telemetry console",        "state": "done",     "note": "v1.0 shipped"},
    {"title": "CSV / GPX / JSON export",      "state": "done",     "note": "v1.0 shipped"},
    {"title": "Mobile app ingest webhook",    "state": "progress", "note": "v1.1 — real BLE bridge"},
    {"title": "Offline MBTiles map cache",    "state": "planned",  "note": "v1.1 backlog"},
    {"title": "Auth + household invite codes","state": "planned",  "note": "v1.2 if multi-household"},
    {"title": "Sentry error tracking",        "state": "planned",  "note": "v1.1"},
    {"title": "OTA firmware UI (Web DFU)",    "state": "planned",  "note": "v2.0 — needs Web Bluetooth"},
]


def _child_id(request: Request) -> int:
    try:
        return int(request.query_params.get("child", 1))
    except ValueError:
        return 1


def ctx(request: Request, active: str, **extra) -> dict:
    return {
        "request":     request,
        "app_name":    APP_NAME,
        "app_tagline": APP_TAGLINE,
        "nav":         NAV,
        "active":      active,
        **extra,
    }


def _toast(html: str, msg: str, status: int = 200) -> HTMLResponse:
    safe = (msg or "").encode("ascii", "replace").decode("ascii")
    return HTMLResponse(html, status_code=status, headers={"X-Toast": safe})


def _fmt_duration(minutes: int) -> str:
    h, m = divmod(minutes, 60)
    return f"{h}h {m}m" if h else f"{m}m"


# ── Telemetry simulator ────────────────────────────────────────────────────────

_STATES = ["ACTIVE", "LIGHT", "STILL", "SLEEP"]


def _sim_telemetry(child_id: int) -> dict:
    t = time.time()
    # deterministic variation based on time + child_id
    seed = t * 0.1 + child_id * 100
    s    = math.sin
    c    = math.cos
    conn = db.get_conn()
    loc  = db.get_latest_location(conn, child_id)
    conn.close()
    lat = (loc["lat"] if loc else db.BASE_LAT) + s(t * 0.05) * 0.00002
    lng = (loc["lng"] if loc else db.BASE_LNG) + c(t * 0.05) * 0.00002
    return {
        "timestamp":      datetime.now().isoformat(timespec="seconds"),
        "lat":            round(lat, 6),
        "lng":            round(lng, 6),
        "accel_x":        round(s(seed)       * 1.8 + 0.2, 3),
        "accel_y":        round(c(seed * 1.3) * 2.1,       3),
        "accel_z":        round(9.81 + s(seed * 0.7) * 0.4, 3),
        "gyro_x":         round(s(seed * 2)   * 12.0,      2),
        "gyro_y":         round(c(seed * 1.7) * 8.5,       2),
        "gyro_z":         round(s(seed * 0.9) * 5.2,       2),
        "rssi":           int(-65 + s(t * 0.03) * 12),
        "battery_pct":    max(15, min(100, 78 - int(t * 0.001) % 30)),
        "activity_state": _STATES[int(t * 0.2 + child_id) % len(_STATES)],
    }


# ── Page routes ────────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request):
    cid  = _child_id(request)
    conn = db.get_conn()
    children  = db.get_children(conn)
    child     = db.get_child(conn, cid) or children[0]
    loc       = db.get_latest_location(conn, cid)
    sleep_recs= db.get_sleep_records(conn, cid, days=1)
    activity  = db.get_activity_today(conn, cid)
    conn.close()

    total_steps  = sum(r["step_count"] for r in activity)
    overnight    = next((r for r in sleep_recs if r["nap_type"] == "overnight"), None)
    sleep_label  = _fmt_duration(overnight["duration_min"]) if overnight else "—"
    sleep_quality= overnight["quality_score"] if overnight else 0

    stats = [
        {"label": "Battery",      "value": f'{child["battery_pct"]}%',  "delta": "▲ charged 2h ago", "dir": "up",   "icon": "🔋"},
        {"label": "BLE Status",   "value": "Live" if child["ble_connected"] else "Offline",
         "delta": "last 30s",     "dir": "up" if child["ble_connected"] else "down",  "icon": "📡"},
        {"label": "Steps Today",  "value": f'{total_steps:,}',           "delta": "active since 8am", "dir": "up",   "icon": "👟"},
        {"label": "Sleep Last Night", "value": sleep_label,              "delta": f'quality {sleep_quality}/100', "dir": "up", "icon": "😴"},
    ]
    return templates.TemplateResponse(
        request, "pages/dashboard.html",
        ctx(request, "dashboard", child=child, children=children,
            stats=stats, loc=loc, activity=activity[:8])
    )


@app.get("/tracking", response_class=HTMLResponse)
def tracking(request: Request):
    cid  = _child_id(request)
    conn = db.get_conn()
    children = db.get_children(conn)
    child    = db.get_child(conn, cid) or children[0]
    trail    = db.get_trail(conn, cid, limit=36)
    conn.close()
    trail_pts = [[r["lat"], r["lng"]] for r in reversed(trail)]
    latest    = trail[-1] if trail else None
    return templates.TemplateResponse(
        request, "pages/tracking.html",
        ctx(request, "tracking", child=child, children=children,
            trail_pts=trail_pts, latest=latest)
    )


@app.get("/analytics", response_class=HTMLResponse)
def analytics(request: Request):
    cid  = _child_id(request)
    conn = db.get_conn()
    children   = db.get_children(conn)
    child      = db.get_child(conn, cid) or children[0]
    sleep_recs = db.get_sleep_records(conn, cid, days=7)
    activity   = db.get_activity_today(conn, cid)
    conn.close()

    # Group sleep by date: keep last overnight + last nap per day
    from collections import defaultdict
    day_sleep: dict[str, dict] = defaultdict(lambda: {"overnight": None, "nap": None})
    for r in sleep_recs:
        d = r["start_time"][:10]
        if r["nap_type"] == "overnight":
            day_sleep[d]["overnight"] = dict(r)
        else:
            day_sleep[d]["nap"] = dict(r)
    sleep_days = sorted(day_sleep.items(), reverse=True)[:7]

    total_sleep = sum(
        (v["overnight"]["duration_min"] or 0) for _, v in sleep_days if v["overnight"]
    )
    total_steps = sum(r["step_count"] for r in activity)

    return templates.TemplateResponse(
        request, "pages/analytics.html",
        ctx(request, "analytics", child=child, children=children,
            sleep_days=sleep_days, activity=activity,
            total_sleep=_fmt_duration(total_sleep),
            total_steps=total_steps,
            fmt_duration=_fmt_duration)
    )


@app.get("/devices", response_class=HTMLResponse)
def devices(request: Request):
    conn      = db.get_conn()
    children  = db.get_children(conn)
    conn.close()
    gps_modes = {
        "high_security": {"label": "High-Security", "detail": "5s interval · 18–24h battery"},
        "battery_saver": {"label": "Battery-Saver",  "detail": "30s interval · 3–4 day battery"},
    }
    return templates.TemplateResponse(
        request, "pages/devices.html",
        ctx(request, "devices", children=children, gps_modes=gps_modes)
    )


@app.get("/console", response_class=HTMLResponse)
def console(request: Request):
    cid  = _child_id(request)
    conn = db.get_conn()
    children = db.get_children(conn)
    child    = db.get_child(conn, cid) or children[0]
    conn.close()
    return templates.TemplateResponse(
        request, "pages/console.html",
        ctx(request, "console", child=child, children=children)
    )


@app.get("/roadmap", response_class=HTMLResponse)
def roadmap(request: Request):
    return templates.TemplateResponse(
        request, "pages/roadmap.html",
        ctx(request, "roadmap", roadmap=ROADMAP_ITEMS)
    )


# ── HTMX partial routes ────────────────────────────────────────────────────────

@app.get("/api/telemetry/row/{child_id}", response_class=HTMLResponse)
def telemetry_row(child_id: int, request: Request):
    row = _sim_telemetry(child_id)
    return templates.TemplateResponse(request, "partials/telemetry_row.html", {"row": row})


@app.get("/api/battery/{child_id}", response_class=HTMLResponse)
def battery_partial(child_id: int, request: Request):
    conn  = db.get_conn()
    child = db.get_child(conn, child_id)
    conn.close()
    pct = child["battery_pct"] if child else 0
    color = "success" if pct > 30 else ("warning" if pct > 15 else "danger")
    html = (
        f'<span class="badge badge--{color}" style="font-size:13px">'
        f'🔋 {pct}%</span>'
    )
    return HTMLResponse(html)


@app.get("/api/stats/{child_id}", response_class=HTMLResponse)
def stats_partial(child_id: int, request: Request):
    conn  = db.get_conn()
    child = db.get_child(conn, child_id)
    act   = db.get_activity_today(conn, child_id)
    conn.close()
    steps = sum(r["step_count"] for r in act)
    ble   = child["ble_connected"] if child else 0
    html  = (
        f'<span class="badge badge--{"success" if ble else "danger"}">'
        f'{"● Live" if ble else "● Offline"}</span> '
        f'<span class="muted">· {steps:,} steps today</span>'
    )
    return HTMLResponse(html)


@app.get("/api/location/json/{child_id}")
def location_json(child_id: int):
    conn = db.get_conn()
    loc  = db.get_latest_location(conn, child_id)
    conn.close()
    if not loc:
        return JSONResponse({"error": "no data"}, status_code=404)
    return JSONResponse({
        "lat":         loc["lat"],
        "lng":         loc["lng"],
        "accuracy_m":  loc["accuracy_m"],
        "battery_pct": loc["battery_pct"],
        "timestamp":   loc["timestamp"],
    })


# ── Device actions ─────────────────────────────────────────────────────────────

@app.post("/api/devices/{child_id}/gps-mode", response_class=HTMLResponse)
def set_gps_mode(child_id: int, mode: str = Form(...)):
    conn = db.get_conn()
    db.set_gps_mode(conn, child_id, mode)
    conn.close()
    labels = {"high_security": "High-Security (5s)", "battery_saver": "Battery-Saver (30s)"}
    label  = labels.get(mode, mode)
    badge_class = "accent" if mode == "high_security" else "warning"
    html = f'<span class="badge badge--{badge_class}" id="gps-mode-badge-{child_id}">{label}</span>'
    return _toast(html, f"GPS mode → {label}")


# ── Export routes ──────────────────────────────────────────────────────────────

@app.get("/export/{child_id}/csv")
def export_csv(child_id: int):
    conn      = db.get_conn()
    child     = db.get_child(conn, child_id)
    trail     = db.get_trail(conn, child_id, limit=500)
    sleep_recs= db.get_sleep_records(conn, child_id, days=30)
    activity  = db.get_activity_today(conn, child_id)
    conn.close()

    buf = io.StringIO()
    w   = csv.writer(buf)

    w.writerow(["# KidTrack Export — " + (child["name"] if child else str(child_id))])
    w.writerow([])
    w.writerow(["## Location History"])
    w.writerow(["timestamp", "lat", "lng", "accuracy_m", "battery_pct"])
    for r in reversed(trail):
        w.writerow([r["timestamp"], r["lat"], r["lng"], r["accuracy_m"], r["battery_pct"]])
    w.writerow([])
    w.writerow(["## Sleep Records"])
    w.writerow(["start_time", "end_time", "duration_min", "quality_score", "nap_type"])
    for r in sleep_recs:
        w.writerow([r["start_time"], r["end_time"], r["duration_min"], r["quality_score"], r["nap_type"]])
    w.writerow([])
    w.writerow(["## Activity Today"])
    w.writerow(["hour", "activity_label", "step_count"])
    for r in activity:
        w.writerow([r["hour"], r["activity_label"], r["step_count"]])

    name = (child["name"] if child else f"child{child_id}").lower()
    return StreamingResponse(
        io.BytesIO(buf.getvalue().encode()),
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="kidtrack-{name}.csv"'}
    )


@app.get("/export/{child_id}/gpx")
def export_gpx(child_id: int):
    conn  = db.get_conn()
    child = db.get_child(conn, child_id)
    trail = db.get_trail(conn, child_id, limit=500)
    conn.close()

    name   = child["name"] if child else f"Child {child_id}"
    pts    = "\n".join(
        f'      <trkpt lat="{r["lat"]}" lon="{r["lng"]}">'
        f'<time>{r["timestamp"]}</time>'
        f'<extensions><battery>{r["battery_pct"]}</battery></extensions>'
        f'</trkpt>'
        for r in reversed(trail)
    )
    gpx = f"""<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="KidTrack Web Companion"
     xmlns="http://www.topografix.com/GPX/1/1">
  <trk>
    <name>KidTrack — {name}</name>
    <trkseg>
{pts}
    </trkseg>
  </trk>
</gpx>"""
    fname = f"kidtrack-{name.lower()}.gpx"
    return Response(
        content=gpx.encode(),
        media_type="application/gpx+xml",
        headers={"Content-Disposition": f'attachment; filename="{fname}"'}
    )


@app.get("/export/{child_id}/json")
def export_json(child_id: int):
    import json as _json
    conn      = db.get_conn()
    child     = db.get_child(conn, child_id)
    trail     = db.get_trail(conn, child_id, limit=500)
    sleep_recs= db.get_sleep_records(conn, child_id, days=30)
    activity  = db.get_activity_today(conn, child_id)
    conn.close()

    data = {
        "exported_at":       datetime.now().isoformat(),
        "child":             dict(child) if child else {},
        "location_history":  [dict(r) for r in reversed(trail)],
        "sleep_records":     [dict(r) for r in sleep_recs],
        "activity_today":    [dict(r) for r in activity],
    }
    name = (child["name"] if child else f"child{child_id}").lower()
    return Response(
        content=_json.dumps(data, indent=2).encode(),
        media_type="application/json",
        headers={"Content-Disposition": f'attachment; filename="kidtrack-{name}.json"'}
    )


@app.get("/healthz", response_class=PlainTextResponse)
def healthz():
    return "ok"
